here we are discussing about left and right nav bar

in css here we are stying the navbar by giving the flex  i mean like display : flex ;

and here we are aligning to the rows by giving the flex direction to rows i mean like flex-direction: row;

and here we are justifying the content to the center or left or right or space-between 



For fonts styles we wanna go to fonts.google.com 


attribute letter spacing is used to give space between each letter letter-spacing : 2px;

