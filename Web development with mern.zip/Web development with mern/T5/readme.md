Html forms is used to collect the data from the user , They allow users to input information such as text ,number,selections and then submit the data to a server for processing 


Forms are very crucil part of intracctive web applications and are created using varios htnl elements .