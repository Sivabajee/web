Css Postioning :
Css Provides Several postioning Properties that help you specify where an element should be displayed .

Postion values : static , relative , absolute , fixed , sticky 

Static postion is the one where the all the elements are actually in Correct postion( I mean like the postion which is as it is  )

Realtive postion is the one we can fix the postion according to the i mean with refernce to the actual postion by using attributes like top , and left attributes for instance top : 30px and left :20px 

ABSOLUTE POSTION is the one we can take refernce of the parent element of the particualr class in this case body element is the parent 


and the next postion is sticky which is particular content is sticky to web page after scroccing also and remaing contents well move 

we are moving the contents of the web page by using the body elements with attribute height : 200vh 


and then we have another postion called fixed postion which is same as sticky postion and we can adjust this by using the the top , left and right attributes 

